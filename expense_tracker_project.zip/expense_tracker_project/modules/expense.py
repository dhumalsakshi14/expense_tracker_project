import re
from datetime import datetime

class Expense:
    DATE_PATTERN = r"^\d{4}-\d{2}-\d{2}$"

    def __init__(self, amount: float, category: str, date: str):
        self.amount = amount
        self.category = category.strip().title()
        self.date = date
        self.validate()

    def validate(self):
        if self.amount <= 0:
            raise ValueError("Amount must be greater than zero.")

        if not self.category:
            raise ValueError("Category cannot be empty.")

        if not re.match(self.DATE_PATTERN, self.date):
            raise ValueError("Invalid date format. Use YYYY-MM-DD.")

        # Validate real date (leap years, etc.)
        try:
            datetime.strptime(self.date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Invalid calendar date.")

    def to_file_string(self):
        return f"{self.amount},{self.category},{self.date}\n"

    @staticmethod
    def from_file_string(line: str):
        amount, category, date = line.strip().split(",")
        return Expense(float(amount), category, date)

    def __str__(self):
        return f"{self.amount:<10.2f} {self.category:<15} {self.date}"
