def summarize_by_category(expenses):
    summary = {}

    for expense in expenses:
        summary.setdefault(expense.category, 0)
        summary[expense.category] += expense.amount

    return summary
