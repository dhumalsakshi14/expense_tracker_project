import os
from modules.expense import Expense

DATA_FILE = "data/expenses.txt"

def ensure_file_exists():
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(DATA_FILE):
        open(DATA_FILE, "w").close()

def save_expense(expense: Expense):
    ensure_file_exists()
    with open(DATA_FILE, "a") as file:
        file.write(expense.to_file_string())

def load_expenses():
    ensure_file_exists()
    expenses = []

    try:
        with open(DATA_FILE, "r") as file:
            for line in file:
                if line.strip():
                    expenses.append(Expense.from_file_string(line))
    except Exception:
        print("⚠️ Error reading expense file.")

    return expenses
